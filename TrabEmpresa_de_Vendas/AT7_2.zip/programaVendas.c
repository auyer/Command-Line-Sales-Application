//
//  programaVendas.c
//  TrabEmpresa de Vendas
//
//  Created by Rafael Auyer on 10/21/15.
//  Copyright © 2015 Rafael Auyer. All rights reserved.
//

#include <stdio.h>
#include "programaVendas.h"
#include "EntradaSaida.h"

typedef struct
{
    char nome[50];
    int idade;
    char cpf[15];
    int matricula;
    
    
} cadFuncionario;

typedef struct
{
    char nome[50];
    int cod;
    int quantidade;
    float valor;
    
    
} cadMaterial;


void menu(){
    char escolha;
    printf("Escolha sua opçao ");
    scanf(" %c", & escolha);
    switch(escolha){
        case '1':
            cadastroFuncionario();
            //cadastro de funcionario
            break;
        case '2':
            consultaFuncionario();
            //consulta de funcionario
            break;
        case '3':
            cadastroMateriais();
            //cadastra os materiais
            break;
        case '4':
            alteracaoMaterial();
            //alteracao de materiais
            break;
        case '5':
            consultaMaterialCod();
            //consulta de materiais por codigo
            break;
        case '6':
            consultaMaterialDesc();
            //consulta de materiais por descricao
            break;
        case '7':
            controleVendas();
            //controle de vendas (Nota fiscal e consietencia de estoque)
            break;
        case '8':
            estoqueAbaixoMinimo();
            //lista de produtos abaixo do estoque
            break;
        default:
            printf("Opcao incorreta, escolha novamente");
            menu();
    }
}
